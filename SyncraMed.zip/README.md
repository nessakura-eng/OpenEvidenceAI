
  # SyncraMed

  This is a code bundle for SyncraMed. The original project is available at https://www.figma.com/design/N3erNTpwShJY8O4kqq8yo2/SyncraMed.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  